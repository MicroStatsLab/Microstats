r####################################
#growth curve function
#written by Rich Fitzjohn  in Sally Otto's lab
####################################
nderiv <- function(fit, x, eps=1e-5)
  (predict(fit, x + eps) - predict(fit, x - eps))/(2 * eps)

spline.slope <- function(x, y, n=101, eps=1e-5)
  max(nderiv(loess(log(y) ~ x, degree=1, span=0.1),
             seq(min(x), max(x), length=n)), na.rm=TRUE)

spline.slope.dat <- function(d, ...)
  sapply(d[-1], spline.slope, x=d$t, ...)

se <- function(x, na.rm=TRUE) sqrt(var(x, na.rm=TRUE)/(length(x) - 1))

#read in OD values
d <- read.csv("GrowthRates_forLGR.csv")
names(d) <- c("t", paste("C", seq(length=ncol(d)-1), sep=""))
d <- d[complete.cases(d$t),]

#read in wells information
wells <- read.csv("GrowthRates_forLGR_wells.csv")

#calculate growth rate
lgr <- spline.slope.dat(d)

# max OD
maxOD <- apply(d[,2:length(d)], 2, function(x) max(x))

#combine
data <- data.frame(wells, lgr, maxOD)
ddn <- split(data, data$Environment)

par(mfrow=c(3, 2))
for(i in c(6, 5, 4, 2, 3, 1)){
  print(names(ddn)[i])
  plot(as.numeric(as.factor(ddn[[i]]$Strain)), ddn[[i]]$lgr, main= names(ddn)[i], ylim=c(0,0.3))
  test <- aov(ddn[[i]]$lgr~ddn[[i]]$Strain)
  print(summary(aov(ddn[[i]]$lgr~ddn[[i]]$Strain)))
  print(TukeyHSD(test))
}

data.ag <- aggregate(data[c("lgr","maxOD")], data[c("Strain", "Environment")], mean)
data.se <- aggregate(data[c("lgr","maxOD")], data[c("Strain", "Environment")], se)

data_ag <- cbind(data.ag, data.se[,3:4 ])
names(data_ag)[5:6] <- c("lgr.se", "maxOD.se")
data_ag$numEnviro <- rep(c(6, 5, 4, 2, 3, 1), each=3)
data_ag$col <- rep(c("black", "goldenrod", "purple"))

ddn_ag <- split(data_ag, data_ag$Environment)

pdf("/Users/acgerstein/Nextcloud/Umanitoba/Research/Collaborations/Ned/growthRates/growthRate.pdf", width=6, height=4.5)
par(oma=c(3, 1, 1, 1))
plot(data_ag$numEnviro, data_ag$lgr, col=data_ag$col, pch=19, yaxt="n", xaxt="n", ylab="Growth rate", xlab="", xlim=c(0.7, 6.3), cex=1.3, ylim=c(0, 0.3))
axis(2, las=2, at=c(0, 0.1, 0.2, 0.3))
axis(1, at=1:6, labels=FALSE)
text(1:6,  -0.03, c("LB", "NMM(19/0/30)", "NMM(19/30/1)", "NMM(13/30/0)", "NMM(0/30/0)", "NMM(0/100/0)"), srt = -45, xpd=NA, adj=0, cex=0.8)
arrows(data_ag$numEnviro, data_ag$lgr - data_ag$lgr.se, data_ag$numEnviro, data_ag$lgr + data_ag$lgr.se, length=0)
legend("topright", col=c("black", "goldenrod", "purple"), pch=19, legend=c("TUB0", "TUB85", "TUB170"))
mtext("Environment", line=4, side=1)
text(data_ag$numEnviro+0.2, data_ag$lgr, c("B", "B", "A", "B", "B", "A", "C", "B", "A", "B", "B", "A", "B", "B", "A", "B", "A", "B"), cex=0.5)
dev.off()
system("open growthRate.pdf")


